package fuzzy4j.util;

/**
 * @author Soren <sorend@gmail.com>
 */
public interface Range {
    public boolean within(double value);
}
